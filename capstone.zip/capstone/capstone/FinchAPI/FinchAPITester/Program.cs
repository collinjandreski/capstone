using System;
using FinchAPI;

namespace FinchAPITester
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			Finch bird = new Finch(); // Instantiate the Finch object
            bird.connect(); // Connect to the Finch

            //
            //intro
            //


            Console.WriteLine("hello, welcome to the talent show. press enter key to start");
            Console.ReadLine();
            Console.WriteLine("rave ligths activated");

            //
            //led display
            //


            for (int i = 0; i < 5; i++)
            {

                bird.setLED(255, 0, 0);
                bird.wait(200);
                bird.setLED(0, 255, 0);
                bird.wait(300);
                bird.setLED(0, 0, 255);
                bird.wait(400);
            }


            //
            //partition
            //


            Console.Clear();
            Console.WriteLine("press enter key to begin the motor function display");
            Console.ReadLine();


            //
            //motor function
            //


            bird.setMotors(200, 200);
            bird.wait(1000);

            for (int i = 0; i < 5; i++)
            {
                bird.setMotors(-100, 100);
                bird.wait(1000);
                bird.setMotors(300, -300);
                bird.wait(333);
                bird.setMotors(0,0);
            }



            //
            //toner music "surfin bird"
            //


            Console.Clear();
            Console.WriteLine("to make the bird sing press enter");
            Console.ReadLine();


            for (int i = 0; i < 3; i++)
            {


                bird.wait(2000);
                bird.noteOn(493);
                bird.wait(200);
                bird.noteOff();
                bird.wait(200);

                bird.noteOn(523);
                bird.wait(100);
                bird.noteOff();
                bird.wait(100);

                bird.noteOn(587);
                bird.wait(100);
                bird.noteOff();
                bird.wait(100);
                bird.setLED(55,55,0);

                bird.noteOn(659);
                bird.wait(50);
                bird.noteOff();
                bird.wait(50);

                bird.noteOn(659);
                bird.wait(50);
                bird.noteOff();
                bird.wait(50);
                bird.setLED(100,10,100);

                bird.noteOn(659);
                bird.wait(50);
                bird.noteOff();
                bird.wait(50);

                bird.noteOn(659);
                bird.wait(50);
                bird.noteOff();
                bird.wait(50);

                //
                //1st rest
                //

                bird.noteOn(493);
                bird.wait(400);
                bird.noteOff();
                bird.wait(500);
                bird.setLED(55, 55, 0);

                bird.noteOn(493);
                bird.wait(200);
                bird.noteOff();
                bird.wait(200);

                bird.noteOn(659);
                bird.wait(400);
                bird.noteOff();
                bird.wait(400);
                bird.setLED(20,100,10);

                bird.noteOn(659);
                bird.wait(100);
                bird.noteOff();
                bird.wait(100);

                //
                //2nd rest
                //

                bird.noteOn(493);
                bird.wait(100);
                bird.noteOff();
                bird.wait(600);

                bird.noteOn(659);
                bird.wait(200);
                bird.noteOff();
                bird.wait(300);

                bird.noteOn(659);
                bird.wait(200);
                bird.noteOff();
                bird.wait(300);

                //
                //3rd rest
                //

                bird.noteOn(493);
                bird.wait(400);
                bird.noteOff();
                bird.wait(600);
                bird.setLED(55, 75, 0);

                bird.noteOn(659);
                bird.wait(200);
                bird.noteOff();
                bird.wait(200);


                bird.noteOn(659);
                bird.wait(400);
                bird.noteOff();
                bird.wait(400);

                bird.noteOn(659);
                bird.wait(200);
                bird.noteOff();
                bird.wait(200);

                bird.noteOn(493);
                bird.wait(50);
                bird.noteOff();
                bird.wait(50);
            }

            Console.Clear();
            Console.WriteLine("press enter to engage disco mode");
            Console.ReadLine();




			for (int i = 0; i < 5; i++)
			{

				bird.setLED(255, 0, 0);
				for (int k = 0; k < 5; k++)
				{
					bird.setMotors(-100, 100); 
					bird.wait(100);
					bird.setMotors(300, -300);
					bird.wait(33);
					bird.setMotors(0, 0);
				}
				
				bird.setLED(0, 255, 0);
				for (int k = 0; k < 5; k++)
				{
					bird.setMotors(-100, 100);
					bird.wait(100);
					bird.setMotors(300, -300);
					bird.wait(33);
					bird.setMotors(0, 0);
				}
				
				bird.setLED(0, 0, 255);
				for (int k = 0; k < 5; k++)
				{
					bird.setMotors(-100, 100);
					bird.wait(1000);
					bird.setMotors(300, -300);
					bird.wait(333);
					bird.setMotors(0, 0);
				}
				
			}
                   







			// Disconnect from Finch
            bird.disConnect();
		}
	}
}
