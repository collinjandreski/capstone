using System;
using System.Threading;
using System.Diagnostics;
using HidSharp;

namespace FinchAPI
{
	/// <summary>
	/// Finch class, contains methods for connecting to and controlling Finch, as well as reading Finch sensor data.
	/// Author: Justin Lee
	/// Copyright: 2014
	/// Released 
	/// </summary>
	public class Finch
	{
		#region globals
		private HidStream stream = null;
		private Thread keepAliveThread = null;
		private bool notConnected = true;
		private int red = 0;
		private int green = 0;
		private int blue = 0;
		private byte changeByte = 1;
		private byte READSIZE = 9;
		private byte WRITESIZE = 9;
		private string OS = "Unknown";
		private long lastSend;

		#endregion

		#region connect/disconnect methods

		/// <summary>
		/// Connects to the Finch. This method must be called before any other Finch methods can be called
		/// </summary>
		/// <returns>True if connection succeeded or already existed, false otherwise</returns>
		public bool connect(){
			if (System.IO.Directory.Exists("/Applications")) {
				OS = "Mac";
				READSIZE = 8;
				WRITESIZE = 8;
			} else if (System.Environment.OSVersion.Platform.ToString ().Contains ("Unix")) {
				READSIZE = 11;
				OS = "Linux";
			} else {
				OS = "Windows";
			}

			if (notConnected) {
				try{
					HidDeviceLoader loader = new HidDeviceLoader ();
					HidDevice device = loader.GetDeviceOrDefault (0x2354,0x1111);
					stream = device.Open();
				}catch{
				}
				notConnected = false;
			}
			if (stream != null && keepAliveThread == null) {
				keepAliveThread = new Thread(new ThreadStart(keepAlive)); // Start the thread that keeps Finch out of idle mode while program is running
				keepAliveThread.Start();
				return true;
			}else if(stream!=null){
				return true;
			}
			else
				return false;
		}

		/// <summary>
		/// Disconnects the Finch and puts it back in idle mode. Methods that set outputs or get sensor data will fail after disconnect is called. We recommend you
		/// call this before your program ends.
		/// </summary>
		public void disConnect(){
			if (stream != null) {
				keepAliveThread.Abort ();
				byte[] report = makePacket((byte)'R');
				WriteBytes (report);
			}
			stream = null;
			notConnected = true;
		}
		#endregion

		#region outputs
		/// <summary>
		/// Sets the color of the Finch's beak.
		/// </summary>
		/// <param name="r">Red LED intensity, 0 to 255</param>
		/// <param name="g">Green LED intensity, 0 to 255</param>
		/// <param name="b">Blue  LED intensity, 0 to 255</param>
		public void setLED(int r, int g, int b){
			if (stream != null) {
				// Check to make sure arguments are in range/put them in range if they are not
				if (r < 0)
					r = 0;
				if (r > 255)
					r = 255;
				if (g < 0)
					g = 0;
				if (g > 255)
					g = 255;
				if (b < 0)
					b = 0;
				if (b > 255)
					b = 255;
				// Used for keep alive
				red = r;
				blue = b;
				green = g;
				byte[] report = makePacket((byte)'O', (byte)r, (byte)g, (byte)b);
				WriteBytes (report);
			}
		}

		/// <summary>
		/// Sets the power of the Finch's wheels
		/// </summary>
		/// <param name="left">Left motor power</param>
		/// <param name="right">Right motor power</param>
		public void setMotors(int left, int right){
			if (stream != null) {
				// Keep values in range or put them in range
				if (left < -255)
					left = -255;
				if (left > 255)
					left = 255;
				if (right < -255)
					right = -255;
				if (right > 255)
					right = 255;

				// Convert arguments to those used by the USB protocol - need to use direction and speed, instead of +/-
				byte ldirection = 0;
				byte lspeed;
				byte rdirection = 0;
				byte rspeed;

				if (left < 0)
				{
					lspeed = (byte)(-left);
					ldirection = 1;
				}
				else
					lspeed = (byte)left;
				if (right < 0)
				{
					rspeed = (byte)(-right);
					rdirection = 1;
				}
				else
					rspeed = (byte)right;
				byte[] report = makePacket ((byte)'M', ldirection, lspeed, rdirection, rspeed);
				WriteBytes (report);
			}
		}

		/// <summary>
		/// Turns the finch buzzer on to a certain frequency
		/// </summary>
		/// <param name="frequency">Frequency in Hertz</param>
		public void noteOn(int frequency){
			if (stream != null) {
				byte[] report = makePacket ((byte)'B', 0xFF, 0xFF, (byte)((frequency & 0x0000FFFF)>>8), (byte)(frequency & 0x000000FF));
				WriteBytes (report);
			}
		}

		/// <summary>
		/// Turns off Finch Buzzer
		/// </summary>
		public void noteOff(){
			if (stream != null) {
				byte[] report = makePacket ( (byte)'B', 0x00, 0x00, 0x00, 0x00);
				WriteBytes (report);
			}
		}
		#endregion

		#region light sensors

		/// <summary>
		/// Get left and right light sensors
		/// </summary>
		/// <returns>Two element array containing the the left and right light sensor values (0 to 255)</returns>
		public int[] getLightSensors(){
			if (stream != null) {
				byte[] report = makePacket((byte)'L');
				byte[] readData = WriteBytesRead (report);

				// Collect and format data - note that the first element in readData is always value 0, so we're off by one when returning
				int[] returnData = new int[2];
				int START = 1;
				if (OS == "Linux") 
					START = 2;

				returnData [0] = readData [START];
				returnData [1] = readData [START + 1];

				return returnData;
			}
			return null;
		}

		/// <summary>
		/// Returns the value of the left light sensor
		/// </summary>
		/// <returns>Left light sensor value, 0(dark) to 255(bright)</returns>
		public int getLeftLightSensor(){
			int[] lights = getLightSensors();

			if (lights != null)
				return lights[0];
			else
				return 0;
		}

		/// <summary>
		/// Returns the value of the right light sensor
		/// </summary>
		/// <returns>Right light sensor value, 0(dark) to 255(bright)</returns>
		public int getRightLightSensor(){
			int[] lights = getLightSensors();

			if (lights != null)
				return lights[1];
			else
				return 0;
		}
		#endregion

		#region acceleration/orientation
		/// <summary>
		/// Returns the accelerations experienced by Finch's accelerometer. Values are -1.5g to 1.5g.
		/// </summary>
		/// <returns>An array of 3 doubles holding X, Y, and Z acceleration, null if the read failed.</returns>
		public double[] getAccelerations(){
			if (stream != null) {
				byte[] report = makePacket((byte)'A');
				byte[] readData = WriteBytesRead (report);
				double[] returnData = new double[3];
				// Convert to g's. Acceleration data starts at element 2 of the array
				int START = 2; // position in readData
				if (OS == "Linux") {
					START = 3;
				}

				for (int i = 0; i < 3; i++) {
					if (readData[i+START] > 31)
						returnData[i] = ((double)readData[i+START] - 64) * 1.5 / 32;
					else
						returnData[i] = ((double)readData[i+START]) * 1.5 / 32;
				}
				return returnData;
			} else
				return null;
		}

		/// <summary>
		/// Returns the X (beak to tail) acceleration
		/// </summary>
		/// <returns>Acceleration in gees</returns>
		public double getXAcceleration(){
			double[] accels = getAccelerations();
			if (accels != null)
				return accels[0];
			else
				return 0;
		}

		/// <summary>
		/// Returns the Y (wheel to wheel) acceleration
		/// </summary>
		/// <returns>Acceleration in gees</returns>
		public double getYAcceleration(){
			double[] accels = getAccelerations();
			if (accels != null)
				return accels[1];
			else
				return 0;
		}

		/// <summary>
		/// Returns the Z (top to bottom) acceleration
		/// </summary>
		/// <returns>Acceleration in gees</returns>
		public double getZAcceleration(){
			double[] accels = getAccelerations();
			if (accels != null)
				return accels[2];
			else
				return 0;
		}

		/// <summary>
		/// Finch orientation check
		/// </summary>
		/// <returns>True if the beak is pointed up, false otherwise</returns>
		public bool isBeakUp(){
			double[] accels = getAccelerations();
			if (accels != null)
			{
				if (accels[0] < -0.6 && accels[0] > -1.5 && accels[1] > -0.3 && accels[1] < 0.3 && accels[2] > -0.3 && accels[2] < 0.3)
					return true;
			}
			return false;
		}

		/// <summary>
		/// Finch orientation check
		/// </summary>
		/// <returns>True if the beak is pointed down, false otherwise</returns>
		public bool isBeakDown(){
			double[] accels = getAccelerations();
			if (accels != null)
			{
				if (accels[0] < 1.5 && accels[0] > 0.6 && accels[1] > -0.3 && accels[1] < 0.3 && accels[2] > -0.3 && accels[2] < 0.3)
					return true;
				else
					return false;
			}
			return false;
		}

		/// <summary>
		/// Finch orientation check
		/// </summary>
		/// <returns>True if the Finch is level, false otherwise</returns>
		public bool isFinchLevel(){
			double[] accels = getAccelerations();
			if (accels != null)
			{
				if (accels[0] > -0.5 && accels[0] < 0.5 && accels[1] > -0.5 && accels[1] < 0.5 && accels[2] > 0.65 && accels[2] < 1.5)
					return true;
			}
			return false;
		}

		/// <summary>
		/// Finch orientation check
		/// </summary>
		/// <returns>True if the Finch is upside down, false otherwise</returns>
		public bool isFinchUpsideDown(){
			double[] accels = getAccelerations();
			if (accels != null)
			{
				if (accels[0] > -0.5 && accels[0] < 0.5 && accels[1] > -0.5 && accels[1] < 0.5 && accels[2] > -1.5 && accels[2] < -0.65)
					return true;
			}
			return false;
		}

		/// <summary>
		/// Finch orientation check
		/// </summary>
		/// <returns>True if the Finch's left wheel/wing is pointed down, false otherwise</returns>
		public bool isLeftWingDown(){
			double[] accels = getAccelerations();
			if (accels != null)
			{
				if (accels[0] > -0.5 && accels[0] < 0.5 && accels[1] > 0.6 && accels[1] < 1.5 && accels[2] > -0.5 && accels[2] < 0.5)
					return true;
			}
			return false;
		}

		/// <summary>
		/// Finch orientation check
		/// </summary>
		/// <returns>True if the Finch's right wheel/wing is pointed down, false otherwise</returns>
		public bool isRightWingDown(){
			double[] accels = getAccelerations();
			if (accels != null)
			{
				if (accels[0] > -0.5 && accels[0] < 0.5 && accels[1] > -1.5 && accels[1] < -0.6 && accels[2] > -0.5 && accels[2] < 0.5)
					return true;
			}
			return false;
		}
		#endregion

		#region temperature sensor
		/// <summary>
		/// Gets the temperature measured by the Finch's small temperature sensor.
		/// </summary>
		/// <returns>Ambient temperature in Celcius</returns>
		public double getTemperature(){
			if (stream != null) {
				byte[] report = makePacket((byte)'T');
				byte[] readData = WriteBytesRead (report);
				// Converts data to Celcius
				double returnData;
				if (OS == "Linux") {
					returnData = ((double)readData [2] - 127) / 2.4 + 25;
				} else {
					returnData = ((double)readData [1] - 127) / 2.4 + 25;
				}
				return returnData;
			} else
				return 0;
		}

		#endregion

		#region obstacle sensors
		/// <summary>
		/// Gets a two element boolean array representing the left (element 0) and right (element 1) obstacle sensors. True if an obstacle is detected, false otherwise. 
		/// </summary>
		/// <returns>Array contain Finch obstacle data</returns>
		public bool[] getObstacleSensors(){
			if (stream != null) {
				byte[] report = makePacket((byte)'I');
				byte[] readData = WriteBytesRead (report);

				int START = 1;
				if (OS == "Linux")
					START = 2;

				bool[] returnData = new bool[2];
				if (readData [START] == 1)
					returnData [0] = true;
				else
					returnData [0] = false;
				if (readData [START + 1] == 1)
					returnData [1] = true;
				else
					returnData [1] = false;
				return returnData;
			} else
				return null;
		}

		/// <summary>
		/// Checks if there's an obstacle on the left side
		/// </summary>
		/// <returns>True if there's an obstacle, false otherwise</returns>
		public bool isObstacleLeftSide(){
			bool[] obstacles = getObstacleSensors();
			if (obstacles != null)
			{
				if (obstacles[0])
					return true;
				else
					return false;
			}
			return false;
		}

		/// <summary>
		/// Checks if there's an obstacle on the right side
		/// </summary>
		/// <returns>True if there's an obstacle, false otherwise</returns>
		public bool isObstacleRightSide(){
			bool[] obstacles = getObstacleSensors();
			if (obstacles != null)
			{
				if (obstacles[1])
					return true;
				else
					return false;
			}
			return false;
		}

		#endregion

		#region miscellaneous

		/// <summary>
		/// Utility function to block program execution. Useful if you want to, for example, have the Finch go forward for 1 second and then stop
		/// </summary>
		/// <param name="ms">Time to wait in milliseconds</param>
		public void wait(int ms){
			System.Threading.Thread.Sleep(ms);
		}

		// The Finch requires communication to occur at least once every five seconds. This function is run in a separate thread and sets the LED to 
		// the current LED values - so it changes nothing.
		private void keepAlive(){
			while (true)
			{
				setLED(red, green, blue); // Set the LED to the current values (doesn't change the LED color)
				wait(2000); // do this again in 2 seconds
			}
		}

		#endregion
		#region writing/reading reports
		private byte [] makePacket(params byte [] report) {
			byte [] array = null;
			if (OS == "Mac") {
				array = new byte[report.Length];
				for(int i=0; i < report.Length; i++) {
					array[i] = report[i];
				}
			} else {
				array = new byte[report.Length + 1];
				array[0] = 0;
				for(int i=0; i < report.Length; i++) {
					array[i+1] = report[i];
				}
			}
			return array;
		}

		private void WriteBytes (params byte [] bytes)
		{
			byte[] tbuffer = new byte[WRITESIZE];
			for (int i=0; i < bytes.Length; i++) {
				tbuffer [i] = bytes [i];
			}
			tbuffer [WRITESIZE - 1] = changeByte;
			changeByte++;

			if (stream != null) {
				lock (stream) {
					stream.Write (tbuffer);
					wait (8);
				}
			}
		}

		private byte [] WriteBytesRead (params byte [] bytes)
		{
			byte[] tbuffer = new byte[WRITESIZE];
			for (int i=0; i < bytes.Length; i++) {
				tbuffer [i] = bytes [i];
			}
			byte lastChangeByte = changeByte;
			tbuffer [WRITESIZE - 1] = changeByte;
			changeByte++;
			if (stream != null) {
				lock (stream) {
					stream.Write (tbuffer);
					wait (8);
				}
				byte [] readData = ReadBytes (READSIZE);
				if (OS == "Mac") {
					while (readData[0] != bytes[0] && bytes[0] != (byte)'z') {
						readData = ReadBytes (READSIZE);
					}
				} else {
					while (readData[READSIZE - 1] != lastChangeByte && bytes[1] != (byte)'z') {
						readData = ReadBytes(READSIZE);
					}
				}
				return readData;
			} else {
				return null;
			}
		}

		private byte [] ReadBytes (int size)
		{
			byte [] retval = new byte[size];
			int r = 0;
			if (stream != null) {
				while (r < size) {
					byte [] buffer = null;
					lock (stream) {
						buffer = stream.Read ();
					}
					for (int b = 0; b < buffer.Length; b++) {
						if (r < size)
							retval [r++] = buffer [b];
						else
							System.Console.Error.WriteLine ("Leftover byte on buffer: " + buffer [b]);
					}
				}
			}
			return retval;
		}
		#endregion
	}
}

