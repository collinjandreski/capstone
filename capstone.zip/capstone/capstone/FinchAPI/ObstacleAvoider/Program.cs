using System;
using FinchAPI;

namespace ObstacleAvoider
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			Finch tweety = new Finch ();
			tweety.connect ();
			while (!tweety.isBeakDown()) {
				bool[] obstacles = tweety.getObstacleSensors ();
				if (obstacles [0] && obstacles [1]) {
					Console.WriteLine ("Obstacle Ahead");
					tweety.setMotors (-100, 100);
					tweety.wait (1000);
				} else if (obstacles [0]) {
					Console.WriteLine ("Obstacle Left");
					tweety.setMotors (0,-100);
					tweety.wait (1000);
				} else if (obstacles [1]) {
					Console.WriteLine ("Obstacle Right");
					tweety.setMotors (-100,0);
					tweety.wait (1000);
				} else {
					tweety.setMotors (100, 100);
				}
				tweety.wait(100);
			}
			tweety.disConnect ();
	
		}
	}
}
