using System;
using FinchAPI;

namespace Tones
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			Finch tweety = new Finch ();
			tweety.connect ();
			double tone = 440; //A440
			for (int i = 0; i<=12; i++) { //play one octave starting from A440
				if (tweety.isRightWingDown()) //user can exit by pointing Finch's right wing down
					break;
				if (i != 1 && i != 3 && i != 6 & i != 8 && i != 10) { //make diatonic scale
					tweety.noteOn ((int)(tone * Math.Pow (2, i / 12.0))); //one equal temperament semitone = multiplying by 2^(1/12)
					tweety.wait (500);
				}
			}
			tweety.disConnect ();
		}
	}
}