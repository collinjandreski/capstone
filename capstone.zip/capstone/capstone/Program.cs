﻿using System;
using System.Threading;
using System.Threading.Tasks;
using FinchAPI;

namespace capstone
{
    class MainClass
    {
        static Finch bird = new Finch();
        public static void Main(string[] args)
        {
            displayOpeningScreen();
            displaymainMenu();
            displayClosingScreen();
        }
        #region BaseMethods
        /// <summary>
        /// Displaies the opening screen.
        /// </summary>
        static void displayOpeningScreen()
        {
            Console.ResetColor();
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Clear();
            displayHeader("Welcome to the app");
            displayContinuePrompt();
        }
        /// <summary>
        /// Displaies the header.
        /// </summary>
        /// <param name="headerTitle">Header title.</param>
        static void displayHeader(string headerTitle)
        {
            Console.Clear();
            Console.WriteLine("\n\t\t" + headerTitle);
        }
        /// <summary>
        /// Displaies the continue prompt.
        /// </summary>
        static void displayContinuePrompt()
        {
            Console.WriteLine("\npress any key to continue");
            Console.ReadKey();
        }
        /// <summary>
        /// Displaies the closing screen.
        /// </summary>
        static void displayClosingScreen()
        {
            Console.BackgroundColor = ConsoleColor.Yellow;
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\nthank you for using this app");
            Console.WriteLine("press any key to exit");
            Console.ReadKey();
            Console.Clear();
        }
        /// <summary>
        /// Displaymains the menu.
        /// </summary>
        static void displaymainMenu()
        {
            bool end = false;
            while (!end)
            {
                Console.ResetColor();
                Console.BackgroundColor = ConsoleColor.DarkGreen;
                Console.ForegroundColor = ConsoleColor.Blue;
                string userresponse;
                displayHeader("main menu");
                Console.WriteLine("\n\n\t Please choose one of the following options");
                Console.WriteLine("\tA) connect to the finch");
                Console.WriteLine("\tB) Toggle the accessory.");
                Console.WriteLine("\tC) Drive mode");
                Console.WriteLine("\tD) Laser measurement and calculation");
                Console.WriteLine("\tE) Draw shapes with laser");
                Console.WriteLine("\tF) Eject the Finch");
                Console.WriteLine("\tEsc) press escape to end the program.");
                Console.WriteLine("enter choice");
                userresponse = Console.ReadKey().Key.ToString();
                switch (userresponse)
                {
                    case "A":
                        initializeFinch();
                        break;
                    case "B":
                        ToggleAccesory();
                        break;
                    case "C":
                        DriveMode();
                        break;
                    case "D":
                        LasreMeasurement();
                        break;
                    case "E":
                        MenuForShape();
                        break;
                    case "F":
                        ejectFinch();
                        break;
                    case "Escape":
                        end = true;
                        break;
                }
            }
        }
        /// <summary>
        /// Ejects the finch.
        /// </summary>
        static void ejectFinch()
        {
            bird.disConnect();
            Console.WriteLine("\nthe finch is disconnected");
            displayContinuePrompt();
        }
        /// <summary>
        /// Connect the finch.
        /// </summary>
        static void initializeFinch()
        {
            displayHeader("connect to finch");
            if (bird.connect())
            {
                Console.WriteLine("the bird is connected");
                bird.wait(750);
                bird.setLED(0, 255, 0);
                bird.noteOn(60);
                bird.wait(1000);
                bird.noteOff();
                bird.setLED(0, 0, 0);
            }
            else
            {
                Console.ResetColor();
                Console.BackgroundColor = ConsoleColor.Red;
                Console.WriteLine("the bird is not connected");
                Console.WriteLine("please connect the bird via the usb cable");
                displayContinuePrompt();
            }
        }
        #endregion
        #region DriveMode
        /// <summary>
        /// Drives the finch.
        /// </summary>
        static void DriveMode()
        {
            bool endDrive = false;
            while (!endDrive)
            {
                displayHeader("Use the arrow pad to direct the laser\n\t\tPress enter to turn the laser on.\n\t\tPress the spacebar to turn the laser off\n\t\tpress Esc to return to main menu.");
                string keysasstring;
                keysasstring = Console.ReadKey().Key.ToString();
                Console.WriteLine(keysasstring);
                switch (keysasstring)
                {
                    case "UpArrow":
                        TwoDegreeClickYU();
                        break;
                    case "DownArrow":
                        TwoDegreeClickYD();
                        break;
                    case "RightArrow":
                        TwoDegreeClickXR();
                        break;
                    case "LeftArrow":
                        TwoDegreeClickXL();
                        break;
                    case "Enter":
                        TurnAccessoryOn();
                        break;
                    case "Spacebar":
                        TurnAccessoryOff();
                        break;
                    case "Escape":
                        bird.setMotors(0, 0);
                        endDrive = true;
                        break;
                }
                bird.wait(1);
                bird.setMotors(0, 0);
                Console.Clear();
            }
        }
        /// <summary>
        /// Toggles the accesory.
        /// </summary>
        static void ToggleAccesory()
        {
            bird.connect();
            bool end = false;
            while (!end)
            {
                string userresponse;
                displayHeader("main menu");
                Console.WriteLine("\n\n\t Please choose one of the following options");
                Console.WriteLine("\tA) Turn accessory on");
                Console.WriteLine("\tB) Turn accessory off");
                Console.WriteLine("\tEsc) Return to main menu");
                Console.WriteLine("enter choice");
                userresponse = Console.ReadKey().Key.ToString();
                switch (userresponse)
                {
                    case "A":
                        TurnAccessoryOn();
                        break;
                    case "B":
                        TurnAccessoryOff();
                        break;
                    case "Escape":
                        end = true;
                        break;
                }
            }
        }
        /// <summary>
        /// Turns the accessory on.
        /// </summary>
        static void TurnAccessoryOn()
        {
            Console.Clear();
            bird.setLED(0, 0, 255);
            Console.WriteLine("Acessory is turned on.");
            bird.wait(1000);
        }
        /// <summary>
        /// Turns the accessory off.
        /// </summary>
        static void TurnAccessoryOff()
        {
            Console.Clear();
            bird.setLED(0, 0, 0);
            Console.WriteLine("Accessory is turned off.");
            bird.wait(1000);
        }
        #endregion
        #region laserMeasurement
        /// <summary>
        /// Lasres the measurement.
        /// </summary>
        static void LasreMeasurement()
        {
            double ResultDistance = 1, ResultHeight = 1, ResultTheta = 45;
            bool end = false;
            while (!end)
            {
                Console.ResetColor();
                Console.BackgroundColor = ConsoleColor.DarkGreen;
                Console.ForegroundColor = ConsoleColor.Blue;
                string userresponse;
                displayHeader("laser measurement system");
                Console.WriteLine("\n\tThis portion of the program will allow the use of \n\tbasic trig functions to claculate distances.");
                Console.WriteLine("\tThe given distance can then be measured out by the finch robot laser. \n\tThe accuracy of the finch will vary.");
                Console.WriteLine("\n\n\t Please choose one of the following options");
                Console.WriteLine("\tA) Solve for distance");
                Console.WriteLine("\tB) Solve for height");
                Console.WriteLine("\tC) Solve for angle");
                Console.WriteLine("\tD) Move laser to given measurements");
                Console.WriteLine("\tEnter) Turn accessory on");
                Console.WriteLine("\tSpacebar) Turn accessory off");
                Console.WriteLine("\tEsc) Return to main menu.");
                Console.WriteLine("enter choice");
                userresponse = Console.ReadKey().Key.ToString();
                switch (userresponse)
                {
                    case "A":
                        Console.Clear();
                        Tuple<double, double, double> bin;
                        bin = SolveForUnknownDistance(ResultDistance, ResultTheta, ResultHeight);
                        ResultDistance = bin.Item1;
                        ResultTheta = bin.Item2;
                        ResultHeight = bin.Item3;
                        Console.WriteLine($"the distance is: {ResultDistance}ft.");
                        displayContinuePrompt();
                        break;
                    case "B":
                        Console.Clear();
                        Tuple<double, double, double> bin2;
                        bin2 = SolveForUnknownHeight(ResultHeight, ResultTheta, ResultDistance);
                        ResultHeight = bin2.Item1;
                        ResultTheta = bin2.Item2;
                        ResultDistance = bin2.Item3;
                        Console.WriteLine($"the height is: {ResultHeight}ft.");
                        displayContinuePrompt();
                        break;
                    case "C":
                        Console.Clear();
                        Tuple<double, double, double> bin3;
                        bin3 = SolveForUnknownTheta(ResultTheta, ResultDistance, ResultHeight);
                        ResultTheta = bin3.Item1;
                        ResultDistance = bin3.Item2;
                        ResultHeight = bin3.Item3;
                        ResultTheta = ConvertToDegrees(ResultTheta);
                        Console.WriteLine($"the angle is: {ResultTheta} degrees.");
                        displayContinuePrompt();
                        break;
                    case "D":
                        MoveLaserToTheta(ResultTheta, ResultDistance);
                        Console.WriteLine($"");
                        break;
                    case "Enter":
                        TurnAccessoryOn();
                        break;
                    case "Spacebar":
                        TurnAccessoryOff();
                        break;
                    case "Escape":
                        end = true;
                        break;
                }
            }
        }
        /// <summary>
        /// Gets the distance.
        /// </summary>
        /// <returns>The distance.</returns>
        /// <param name="distance">Distance.</param>
        static double GetDistance(double distance)
        {
            string userresponse;
            Console.WriteLine("please enter the distance you would like to measure in feet");
            userresponse = Console.ReadLine();
            while (!double.TryParse(userresponse, out distance))
            {
                invalidReturn();
                Console.WriteLine("please enter the distance you would like to measure in feet");
                userresponse = Console.ReadLine();
            }
            return distance;
        }
        /// <summary>
        /// Gets the height of finch.
        /// </summary>
        /// <returns>The height of finch.</returns>
        /// <param name="height">Height.</param>
        static double GetHeightOfFinch(double height)
        {
            string userresponse;
            Console.WriteLine("please enter the height of the finch in feet");
            userresponse = Console.ReadLine();
            while (!double.TryParse(userresponse, out height))
            {
                invalidReturn();
                Console.WriteLine("please enter the height of the finch in feet");
                userresponse = Console.ReadLine();
            }
            return height;
        }
        /// <summary>
        /// Gets the angle of measure.
        /// </summary>
        /// <returns>The angle of measure.</returns>
        /// <param name="theta">Theta.</param>
        static double GetAngleOfMeasure(double theta)
        {
            string userresponse;
            Console.WriteLine("please enter the angle of measurement in degrees");
            userresponse = Console.ReadLine();
            while (!double.TryParse(userresponse, out theta))
            {
                invalidReturn();
                Console.WriteLine("please enter the angle of measurement in degrees");
                userresponse = Console.ReadLine();
            }
            return theta;
        }
        /// <summary>
        /// Invalids the return.
        /// </summary>
        static void invalidReturn()
        {
            Console.Clear();
            Console.WriteLine("\t\tim sorry, the given input was invalid. please try again");
        }
        /// <summary>
        /// Solves for unknown distance.
        /// </summary>
        /// <returns>The for unknown distance.</returns>
        /// <param name="result">Result.</param>
        static Tuple<double, double, double> SolveForUnknownDistance(double result, double theta, double height)
        {
            height = 1; theta = 1;
            theta = GetAngleOfMeasure(theta);
            height = GetHeightOfFinch(height);
            result = height * Math.Tan(ConvertToRadians(theta));
            return new Tuple<double, double, double>(result, theta, height);
        }
        /// <summary>
        /// Solves for unknown theta.
        /// </summary>
        /// <returns>The for unknown theta.</returns>
        /// <param name="result">Result.</param>
        static Tuple<double, double, double> SolveForUnknownTheta(double result, double distance, double height)
        {
            height = 1; distance = 1;
            height = GetHeightOfFinch(height);
            distance = GetDistance(distance);
            result = (Math.Atan(distance / height));
            return new Tuple<double, double, double>(result, distance, height);
        }
        /// <summary>
        /// Solves the height of the for unknown.
        /// </summary>
        /// <returns>The for unknown height.</returns>
        /// <param name="result">Result.</param>
        static Tuple<double, double, double> SolveForUnknownHeight(double result, double theta, double distance)
        {
            distance = 1; theta = 1;
            theta = GetAngleOfMeasure(theta);
            distance = GetDistance(distance);
            result = distance / Math.Tan(ConvertToRadians(theta));
            return new Tuple<double, double, double>(result, theta, distance);

        }
        /// <summary>
        /// Moves the laser to theta.
        /// </summary>
        /// <param name="ResultTheta">Result theta.</param>
        static void MoveLaserToTheta(double ResultTheta, double resultdistance)
        {
            double ThetaConversion;
            Console.WriteLine($"The laser will be moved to: {ResultTheta} degrees");
            Console.WriteLine($"The distance of the laser will be: {resultdistance} feet");
            displayContinuePrompt();
            ThetaConversion = ResultTheta/1.7;
            for (int i = 0; i < ThetaConversion; i++)
            {
                TwoDegreeClickYU();
                bird.wait(100);
            }
        }
        /// <summary>
        /// Two degree click.
        /// </summary>
        static void TwoDegreeClickYD()
        {
            bird.setMotors(0, 150);
            bird.wait(1);
            bird.setMotors(0, 0);
        }
        /// <summary>
        /// Two degree click.
        /// </summary>
        static void TwoDegreeClickYU()
        {
            bird.setMotors(0, -150);
            bird.wait(1);
            bird.setMotors(0, 0);
        }
        /// <summary>
        /// Two degree click x.
        /// </summary>
        static void TwoDegreeClickXR()
        {
            bird.setMotors(-150, 0);
            bird.wait(1);
            bird.setMotors(0, 0);
        }
        /// <summary>
        /// Two degree click.
        /// </summary>
        static void TwoDegreeClickXL()
        {
            bird.setMotors(150, 0);
            bird.wait(1);
            bird.setMotors(0, 0);
        }
        static void TwoDegreeClickUR()
        {
            bird.setMotors(-150, -150);
            bird.wait(1);
            bird.setMotors(0, 0);
        }
        static void TwoDegreeClickDR()
        {
            bird.setMotors(-150, 150);
            bird.wait(1);
            bird.setMotors(0, 0);
        }

        /// <summary>
        /// Converts to degrees.
        /// </summary>
        /// <returns>The to degrees.</returns>
        /// <param name="number">Number.</param>
        static double ConvertToDegrees(double number)
        {
            number = number * 180 / Math.PI;
            return number;
        }
        /// <summary>
        /// Converts to radians.
        /// </summary>
        /// <returns>The to radians.</returns>
        /// <param name="number">Number.</param>
        static double ConvertToRadians(double number)
        {
            number = number * Math.PI / 180;
            return number;
        }
        #endregion
        #region shapes
        /// <summary>
        /// Menu for shape.
        /// </summary>
        static void MenuForShape()
        {
            bool end = false;
            while (!end)
            {
                Console.ResetColor();
                Console.BackgroundColor = ConsoleColor.DarkGreen;
                Console.ForegroundColor = ConsoleColor.Blue;
                string userresponse;
                displayHeader("main menu");
                Console.WriteLine("\n\n\t Please choose one of the following options");
                Console.WriteLine("\tA) Draw a square");
                Console.WriteLine("\tB) Draw a triangle.");
                Console.WriteLine("\tEsc) press escape to return to main menu.");
                Console.WriteLine("enter choice");
                userresponse = Console.ReadKey().Key.ToString();
                switch (userresponse)
                {
                    case "A":
                        square();
                        break;
                    case "B":
                        triangle();
                        break;
                    case "Escape":
                        end = true;
                        break;
                }
            }
        }
        /// <summary>
        /// Square this instance.
        /// </summary>
        static void square()
        {
            for (int i = 0; i < 5; i++)
            {
                TwoDegreeClickXL();
            }
            bird.wait(500);
            for (int i = 0; i < 5; i++)
            {
                TwoDegreeClickYU();
            }
            bird.wait(500);
            for (int i = 0; i < 5; i++)
            {
                TwoDegreeClickXR();
            }
            bird.wait(500);
            for (int i = 0; i < 5; i++)
            {
                TwoDegreeClickYD();
            }

        }
        /// <summary>
        /// Triangle this instance.
        /// </summary>
        static void triangle()
        {
            for (int i = 0; i < 5; i++)
            {
                TwoDegreeClickXL();
            }
            bird.wait(500);
            for (int i = 0; i < 5; i++)
            {
                TwoDegreeClickUR();
            }
            bird.wait(500);
            for (int i = 0; i < 5; i++)
            {
                TwoDegreeClickDR();
            }

        }
        #endregion
    }
}
